MØNÉZA GITHUB PAGES
====================

1. Create/sign in to GitHub.
2. Create a new PUBLIC repository. Suggested name: moneza.
3. Upload:
   index.html
   style.css
   script.js
4. Commit the files.
5. Open repository Settings.
6. Open Pages (usually under Code and automation).
7. Under Build and deployment choose:
   Source: Deploy from a branch
   Branch: main
   Folder: / (root)
8. Save.
9. Wait for GitHub to publish the site.
10. Your free URL will normally be:
   https://YOUR-GITHUB-USERNAME.github.io/moneza/

If the repository itself is named YOUR-GITHUB-USERNAME.github.io, the URL is:
https://YOUR-GITHUB-USERNAME.github.io/

The website does not require a custom domain.

NOTE ABOUT IMAGES:
The starter site uses remote Unsplash image URLs so the design works immediately. For a fully owned MØNÉZA identity, replace them later with your own campaign/generated images and local paths such as images/hero.jpg.

SEO:
The site contains a title, description, robots directive, semantic sections and readable editorial content. Google indexing is not guaranteed. After publishing, add the public URL to Google Search Console and request indexing.

EDITING:
To change text/design, edit index.html, style.css or script.js in GitHub and commit. GitHub Pages will republish automatically.
